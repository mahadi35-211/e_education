<?php
	include("Login.php");
?>
<html>
<head>
<LINK REL="SHORTCUT ICON" HREF="fb_files/e_edu_title_icon/knowledge.png" />
	<style>
		#singup_button
		{
			background:#69A74E;
			color:#FFFFFF;
			border-top-color:#3B6E22;
			border-right-color:#2C5115;
			border-left-color:#3B6E22;
			font-size:15px;
			height:30;
			width:75;
			font-weight:bold;
			box-shadow:-5px 0px 10px 1px rgb(0,0,0);
		}
	</style>
     <link href="fb_files/e_edu_font/font.css" rel="stylesheet" type="text/css">
	 
	<link href="e_edu_files/e_edu_index_file/e_edu_css_file/index_css.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="header">
        <img src="e_edu_files/e_edu_index_file/e_edu_image_file/e_learning.png" alt="brandname" class="brandphoto">
        <h1 class="brandname"><span style="color:red">E</span>-Education</h1>
</div>



<div style="position:absolute;left:13.6%; top:14.8%;"> <a href="sign_up.php" style="text-decoration:none; "> <input type="button" value="Sign Up" id="singup_button">    </a> </div>

</body>
</html>