<?php
	include("e_edu_files/e_edu_index_file/e_edu_SignUp_file/SignUp.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Education Sign Up</title>
    <?php	
include("e_edu_files/e_edu_index_file/e_edu_background_file/index_background.php");
?>
    <LINK REL="SHORTCUT ICON" HREF="e_edu_files/e_edu_title_icon/knowledge.png" />
    <link rel="stylesheet" href="./e_edu_files/e_edu_index_file/e_edu_css_file/index_css.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="e_edu_files/e_edu_font/font.css" rel="stylesheet" type="text/css">
    <script type="text/javascript"
        src="e_edu_files/e_edu_index_file/e_edu_js_file/Registration_validation.js"> </script>
</head>
<script>
	function time_get()
	{
		d = new Date();
		mon = d.getMonth()+1;
		time = d.getDate()+"-"+mon+"-"+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes();
		Reg.fb_join_time.value=time;
	}
</script>

<body>
    <div class="container">
        <div class="header">
            <img src="e_edu_files/e_edu_index_file/e_edu_image_file/e_learning.png" alt="brandimg" class="brandphoto">
            <!-- <img src="./e_learning.png" alt="brandimg" class="brandphoto"> -->
            <h1 class="brandname"><span style="color:red">E</span>-Education</h1>
        </div>
        <div class="content_sign_up">
            <form method="post" onSubmit="return check();" name="Reg">
                <div class="sign_up">
                    <h2>Sign Up</h2>
                </div>
                <br><br>
                <div class="textBox">
                    <label>First Name: </label>
                    <input type="text" name="first_name" class="inputbox" maxlength="10" />
                </div>
                <div class="textBox">
                    <label>Last Name: </label>
                    <input type="text" name="last_name" class="inputbox" maxlength="10" />
                </div>
                <div class="textBox">
                    <label>Your Email</label>
                    <input type="email" name="email" size="25" class="inputbox" />
                </div>
                <div class="textBox">
                    <label>Re-enter Email: </label>
                    <input type="email" name="remail" size="25" class="inputbox" />
                </div>
                <div class="textBox">
                    <label>New Password: </label>
                    <input type="password" name="password" size="25" class="inputbox" />
                </div>
                <div class="gender">
                    <label>I am: </label>
                    <select name="sex" style="width:130px;height: 40px;font-size:18px;padding:6px;">
                        <option value="Select Sex:"> Select Sex: </option>
                        <option value="Female"> Female </option>
                        <option value="Male"> Male </option>
                    </select>
                </div>
                <div class="birthday">
                    <label>Birthday: </label>
                    <div class="birthfull">
                        <div class="birth">
                            <select name="month" style="width:100px;font-size:18px;height:100%;padding:8px;border-top-left-radius: 12px; border-bottom-left-radius: 12px;">
                                <option value="Month:"> Month</option>
    
                                <script type="text/javascript">
    
                                    var m = new Array("", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
                                    for (i = 1; i <= m.length - 1; i++) {
                                        document.write("<option value='" + i + "'>" + m[i] + "</option>");
                                    }	
                                </script>
    
                            </select>
                        </div>
    
    
    
                        <div class="birth">
                            <select name="day" style="width:80px;font-size:18px;height:100%;padding:8px;">
                                <option value="Day:"> Day </option>
    
                                <script type="text/javascript">
    
                                    for (i = 1; i <= 31; i++) {
                                        document.write("<option value='" + i + "'>" + i + "</option>");
                                    }
    
                                </script>
    
                            </select>
                        </div>
    
                        <div class="birth">
                            <select name="year" style="width:100px; font-size:18px; height:100%; padding:8px;border-top-right-radius: 12px; border-bottom-right-radius: 12px;">
                                <option value="Year:"> Year </option>
    
                                <script type="text/javascript">
    
                                    for (i = 2010; i >= 1971; i--) {
                                        document.write("<option value='" + i + "'>" + i + "</option>");
                                    }
    
                                </script>
    
                            </select>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="fb_join_time">
                <div class="signUp"> <input type="submit" name="signup" value="Sign Up" id="sign_button" / onClick="time_get()"> </div>

                <div class="back_to_sign">
                <a href="index.php">Already Have Account</a>
            </div>
            </form>
            
        </div>
    </div>

     <!--my_details -->  
     <div style="display:none;" id="my_details">
    <div style="position:absolute;left:12%;top:73%; height:30%; width:30%; z-index:2; background:#000; opacity:0.5; box-shadow:10px 0px 10px 1px rgb(0,0,0);">   </div>
    <!-- <div style="position:absolute;left:13%;top:75%; z-index:3;"> <img src="fb_files/e_edu_index_file/e_edu_background_file/Developer_details/mahadi.jpg" height="165" width="150" style="box-shadow:0px 0px 10px 5px rgb(0,0,0);"> </div> -->
    <div style="position:absolute;left:26%;top:75%; z-index:3; color:#FFF;"> <h2> <?php echo base64_decode("TWFoYWRpIEhhc2Fu"); ?> </h2> </div>
    <div style="position:absolute;left:26%;top:83%; z-index:3; color:#FFF;">  <h3><?php echo base64_decode("bWFoYWRpMzUtMjExQGRpdS5lZHUuYmQ="); ?> </h3> </div>
    <div style="position:absolute;left:26%;top:90%; z-index:3; color:#FFF;"> <h3> <?php echo base64_decode("MDE2ODgwMDgxNTg="); ?>  </h3> </div>
	</div>
    
		
<?php
	include("e_edu_files/e_edu_index_file/e_edu_erorr_file/e_edu_erorr.php");
?>		
</body>

</html>