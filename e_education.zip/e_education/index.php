<?php
	include("Login.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Education</title>
    <?php	
include("e_edu_files/e_edu_index_file/e_edu_background_file/index_background.php");
?>
    <LINK REL="SHORTCUT ICON" HREF="e_edu_files/e_edu_title_icon/knowledge.png" />
    <link href="e_edu_files/e_edu_index_file/e_edu_css_file/index_css.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="e_edu_files/e_edu_font/font.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="e_edu_files/e_edu_index_file/e_edu_image_file/e_learning.png" alt="brandname" class="brandphoto">
            <h1 class="brandname"><span style="color:red">E</span>-Education</h1>
        </div>
        <div class="content">
            <form method="post">
                <div class="box">
                    <span class="icon_img">
                        <i class="far fa-2x fa-user icon"></i>
                    </span>
                    <input type="email" class="usebox" name="username" placeholder="Enter Email" value="<?php
		if(isset($_SESSION['username'])){
			echo $_SESSION['username'];
		}
		?>"/>
                </div>
                <div class="box">
                    <span class="icon_img">
                        <i class="fas fa-2x fa-unlock-alt icon"></i>
                    </span>
                    <input type="password" class="usebox" name="password" placeholder="Enter Password">
                </div>
                <div class="submit"><input type="submit" name="Login" value="Log In" id="login_button" />  </div>
                <div class="other">
                    <div style=" font-size:12; ">  <input type="checkbox" checked="checked">   Keep me logged in </div>
                <div> <a href="Forgot_Password.php" style=" text-decoration:none; font-size: 12px;"> Forgot your password? </a> </div> 
                </div>
                <div class="signup">
                    <a href="sign_up.php">Sign Up</a>
                </div>
            </form>
        </div>
    </div>
    




<!--my_details -->  
<div style="display:none;" id="my_details">
    <div style="position:absolute;left:12%;top:73%; height:30%; width:30%; z-index:2; background:#000; opacity:0.5; box-shadow:10px 0px 10px 1px rgb(0,0,0);">   </div>
    <!-- <div style="position:absolute;left:13%;top:75%; z-index:3;"> <img src="fb_files/e_edu_index_file/e_edu_background_file/Developer_details/mahadi.jpg" height="165" width="150" style="box-shadow:0px 0px 10px 5px rgb(0,0,0);"> </div> -->
    <div style="position:absolute;left:26%;top:75%; z-index:3; color:#FFF;"> <h2> <?php echo base64_decode("TWFoYWRpIEhhc2Fu"); ?> </h2> </div>
    <div style="position:absolute;left:26%;top:83%; z-index:3; color:#FFF;">  <h3><?php echo base64_decode("bWFoYWRpMzUtMjExQGRpdS5lZHUuYmQ="); ?> </h3> </div>
    <div style="position:absolute;left:26%;top:90%; z-index:3; color:#FFF;"> <h3> <?php echo base64_decode("MDE2ODgwMDgxNTg="); ?>  </h3> </div>
	</div>
    
		
<?php
	include("e_edu_files/e_edu_index_file/e_edu_erorr_file/e_edu_erorr.php");
?>	
    
</body>

</html>