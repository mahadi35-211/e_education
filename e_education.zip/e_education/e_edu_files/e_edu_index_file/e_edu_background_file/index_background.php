<html>
<head>
<script>
	function open_developer_details()
	{
		document.getElementById("my_details").style.display='block';
		document.getElementById("my_name").style.textDecoration = "underline"
	}
	function close_developer_details()
	{
		document.getElementById("my_details").style.display='none';
		document.getElementById("my_name").style.textDecoration = "none"
	}
</script>

<link href="../e_edu_css_file/index_css.css" rel="stylesheet" type="text/css">
</head>
<body>
	 <!--head background-->
	
    <div style="position:absolute;right:5%;top:120%;"><font face="myFbFont"> Developer: <span style=" color:black;" onMouseOver="open_developer_details()" onMouseOut="close_developer_details()" id="my_name">  Mahadi Hasan  </span> </font> </div>
    
    
    
    
</body>
</html>
